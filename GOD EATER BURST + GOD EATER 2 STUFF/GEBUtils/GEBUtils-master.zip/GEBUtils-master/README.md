# God Eater Burst Utils

***Original from [nyirsh](https://github.com/nyirsh/GEBUtils)***

- i will probably continue this sooner or later but for now i'll archive this here

# Notes:
- from my testings, the tool is pretty okay-ish when modding the dlc and running it
  through emulators but sadly... it breaks crashes on psp
- Possible chances that you can get
  `Data pack is corrupted. Game cannot continue.
   Returning to title screen.` since the tool is hella bugged?, but who knows
- I'll compile everything so everyone can use it neatly i guess..


`By: Yamato Nagasaki`
