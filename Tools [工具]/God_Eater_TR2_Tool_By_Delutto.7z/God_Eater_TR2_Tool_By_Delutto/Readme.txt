God Eater TR2 Tool
By Delutto - Tribo Gamer Brasil 2018
www.tribogamer.com

Usage: [option] <File.tr2> <OutputFolder>
Options: -e = Export Texts
         -i = Import Texts
         -h = This Help
